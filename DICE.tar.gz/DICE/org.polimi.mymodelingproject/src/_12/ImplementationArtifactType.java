/**
 */
package _12;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Implementation Artifact Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see _12._12Package#getImplementationArtifactType()
 * @model extendedMetaData="name='ImplementationArtifact_._type' kind='elementOnly'"
 * @generated
 */
public interface ImplementationArtifactType extends TImplementationArtifact {
} // ImplementationArtifactType
