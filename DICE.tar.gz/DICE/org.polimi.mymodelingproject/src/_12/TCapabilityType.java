/**
 */
package _12;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>TCapability Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see _12._12Package#getTCapabilityType()
 * @model extendedMetaData="name='tCapabilityType' kind='elementOnly'"
 * @generated
 */
public interface TCapabilityType extends TEntityType {
} // TCapabilityType
