/**
 */
package _12;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Definitions Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see _12._12Package#getDefinitionsType()
 * @model extendedMetaData="name='Definitions_._type' kind='elementOnly'"
 * @generated
 */
public interface DefinitionsType extends TDefinitions {
} // DefinitionsType
