/**
 */
package _12.impl;

import _12.ImplementationArtifactType;
import _12._12Package;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Implementation Artifact Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class ImplementationArtifactTypeImpl extends TImplementationArtifactImpl implements ImplementationArtifactType {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ImplementationArtifactTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return _12Package.Literals.IMPLEMENTATION_ARTIFACT_TYPE;
	}

} //ImplementationArtifactTypeImpl
